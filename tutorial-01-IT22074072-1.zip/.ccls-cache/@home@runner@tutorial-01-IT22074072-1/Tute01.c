/* Exercise 1 - Calculations

   Write a C program to input marks of two subjects. Calculate and print the
   average of the two marks. */

#include <stdio.h>

int main() {
  int x;
  int y;
  float avg;

  printf("Enter subject marks: ");
  scanf("%d", &x);

  printf("Enter subject marks: ");
  scanf("%d", &y);

  avg = (x + y) / 2.0;

  printf("The average mark is %.2f", avg);

  return 0;
}
